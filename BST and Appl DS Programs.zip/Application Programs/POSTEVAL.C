//postfix expression evaluation
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <conio.h>

#define MAX 10

typedef float stackelement;

typedef struct
{stackelement st[MAX];
 int top;
}stacktype;

void initialise(stacktype *sptr)
{sptr->top = -1;}

int push(stacktype *sptr, stackelement ch)
{if(sptr->top==MAX-1)return 0;
 sptr->st[++sptr->top] = ch;
 return 1;
}

int pop(stacktype *sptr, stackelement *noptr)
{if(sptr->top==-1)return 0;
 *noptr = sptr->st[sptr->top--];
 return 1;
}
int memberoper(char ch)
{
char oper[] = {'+', '-', '*', '/','^', '(',')'};
int i;
for (i=0; i < 7; i++) if (ch == oper[i])return 1;
return 0;
}



float operation(float a, float b, char oper)
{ 
  switch(oper)
  { 
    case '+':return(a+b);
    case '-':return(a-b);
    case '*':return(a*b);
    case '/':return(a/b);
    case '^':return(pow(a,b));
  }
}


float evaluation(char posteq[])
{
stacktype s;
int i;
float op1, op2, result;
initialise (&s);
for (i = 0; i < strlen(posteq); i++)
if(memberoper(posteq[i]))
   { pop(&s, &op2);
     pop(&s, &op1);
     push(&s, operation(op1, op2, posteq[i]));
   }
else push(&s, posteq[i] - '0');
pop (&s, &result);
return(result);
}

void main()
{
char posteq[100];
gets(posteq);
puts(posteq);
printf("%f\n", evaluation(posteq));
}
