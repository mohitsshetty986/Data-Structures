//program to convert postfix expression to infix and prefix
//using expression tree
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#define MAX 10
typedef struct node
{ char data;
struct node *left, *right;
} treenode;


typedef treenode * stackelement;

typedef struct
{stackelement st[MAX];
 int top;
}stacktype;

void initialise(stacktype *sptr)
{sptr->top = -1;}

int push(stacktype *sptr, stackelement ch)
{if(sptr->top==MAX-1)return 0;
 sptr->st[++sptr->top] = ch;
 return 1;
}

int pop(stacktype *sptr, stackelement *noptr)
{if(sptr->top==-1)return 0;
 *noptr = sptr->st[sptr->top--];
 return 1;
}

int memberoper(char ch)
{
char oper[] = {'+', '-', '*', '/','^', '(',')'};
int i;
for (i=0; i < 7; i++) if (ch == oper[i])return 1;
return 0;
}

void inorder(treenode *root)
{if(root)
   {if(root->left&&root->right)printf("(");
    inorder(root->left);
    printf("%c", root->data);
    inorder(root->right);
    if(root->left&&root->right)printf(")");
   }
}
void preorder(treenode *root)
{if(root)
   {printf("%c", root->data);
    preorder(root->left);
    preorder(root->right);
   }
}
void postorder(treenode *root)
{if(root)
   {
    postorder(root->left);
    postorder(root->right);
    printf("%c", root->data);
   }
}


void createtree(char post[], treenode **root)
{
int top, i;
stacktype s;
treenode *p, *ptr1, *ptr2;
initialise (&s);
for (i = 0; i <strlen(post); i++)
if(memberoper(post[i]))
  {pop(&s, &ptr2);
   pop(&s, &ptr1);
   p = (treenode*) malloc (sizeof(treenode));
   p->data = post[i];
   p->left = ptr1; p->right = ptr2;
   push(&s, p);
  }
else {p = (treenode*) malloc (sizeof(treenode));
      p->data = post[i];
      p->left = p->right = NULL;
      push(&s, p);
     }
pop(&s, root);
}
void main()
{
char eq[100];
treenode *root;
gets(eq);
createtree(eq, &root);
preorder(root);
printf("\n");
inorder(root);
printf("\n");
postorder(root);
printf("\n");
}
