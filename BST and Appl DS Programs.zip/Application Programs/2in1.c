//two stacks in one array
#include <stdio.h>
#include <conio.h>
#define MAX 10

typedef int stackelement;

typedef struct
{stackelement s[MAX];
 int top1, top2;
}sttype;

void initialise(sttype *sptr)
{ sptr->top1 = -1;
  sptr->top2 = MAX;
}

int push(sttype *sptr, stackelement no, int stno)
{if(sptr->top1+1==sptr->top2)return 0;
 if(stno==1)
    sptr->s[++sptr->top1] = no;
 else sptr->s[--sptr->top2] = no;
 return 1;
}

int pop(sttype *sptr, stackelement *noptr, int stno)
{if(stno==1)
   {if(sptr->top1==-1)return 0;
    *noptr = sptr->s[sptr->top1--];
    return 1;
   }
 else {if(sptr->top2==MAX)return 0;
       *noptr = sptr->s[sptr->top2++];
       return 1;
      }
}

void printstack(sttype st)
{int i;
 if(st.top1==-1)
   printf("Stack 1 is empty\n");
 else {printf("The Current stack 1 is:\n");
         for(i = st.top1; i >= 0; i--)
	  printf("%d\n", st.s[i]);
         }
 if(st.top2==MAX)
   printf("Stack 2 is empty\n");
 else {printf("The Current stack 2 is:\n");
       for(i = st.top2; i < MAX; i++)
	  printf("%d\n", st.s[i]);
      }
}

void main()
{sttype st;
 stackelement no;
 int choice;
 initialise(&st);
 do
 { clrscr();
   printf("Enter 1 to Push in Stack No 1\n");
   printf("Enter 2 to Push in Stack No 2\n");
   printf("Enter 3 to Pop from Stack No 1\n");
   printf("Enter 4 to Pop from Stack No 2\n");
   printf("Enter 5 to print both the stacks\n");
   printf("Enter 6 to quit\n");
   printf("Enter your choice: ");
   scanf("%d", &choice);
   switch(choice)
   {case 1: printf("Enter no: ");
	    scanf("%d", &no);
	    if(push(&st, no, 1))
	      printf("Element pushed on Stack No 1");
	    else printf("Stacks are Full\n");
	    break;
    case 2: printf("Enter no: ");
	    scanf("%d", &no);
	    if(push(&st, no, 2))
	      printf("Element pushed on Stack No 2");
	    else printf("Stacks are Full\n");
	    break;
    case 3: if(pop(&st, &no, 1))
	      printf("No popped = %d\n", no);
	    else printf("Stack No 1 is empty\n");
	    break;
    case 4: if(pop(&st, &no, 2))
	      printf("No popped = %d\n", no);
	    else printf("Stack No 2 is empty\n");
	    break;
    case 5: printstack(st); break;
   }
   getch();
}while(choice != 6);
}
