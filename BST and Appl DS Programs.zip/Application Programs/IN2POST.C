//Infix to Postfix conversion
#include <conio.h>
#include <stdio.h>
#define MAX 10

typedef char stackelement;

typedef struct
{stackelement st[MAX];
 int top;
}stacktype;

void initialise(stacktype *sptr)
{sptr->top = -1;}

int push(stacktype *sptr, stackelement ch)
{if(sptr->top==MAX-1)return 0;
 sptr->st[++sptr->top] = ch;
 return 1;
}

int pop(stacktype *sptr, stackelement *noptr)
{if(sptr->top==-1)return 0;
 *noptr = sptr->st[sptr->top--];
 return 1;
}

//infix to postfix conversion
#include <stdio.h>
#include <string.h>
#include <math.h>
int icp (char oper)
{ switch(oper)
  { case '(':return 4;
    case '^':return 4;
    case '*':return 2;
    case '/':return 2;
    case '+':return 1;
    case '-':return 1;
  }
}
int isp (char oper)
{ switch(oper)
  { case '(':return 0;
    case '^':return 3;
    case '*':return 2;
    case '/':return 2;
    case '+':return 1;
    case '-':return 1;
    case '@':return -1;
  }
}

int memberoper(char ch)
{
char oper[] = {'+', '-', '*', '/','^', '(',')'};
int i;
for (i=0; i < 7; i++) if (ch == oper[i])return 1;
return 0;
}
void convpost(char eq[], char posteq[])
{
stacktype s;
char ch ='@';
int i, postlength = -1;
initialise(&s);
push(&s, ch);
for (i = 0; i < strlen(eq); i++)
if(memberoper(eq[i]))
  if(eq[i]==')')
    { pop(&s, &ch);
      while(ch != '(')
	   {posteq[++postlength] = ch;
	    pop(&s, &ch);
	   }
    }
  else {pop(&s, &ch);
	while(icp(eq[i]) <= isp(ch))
	     {posteq[++postlength] = ch;
	      pop(&s, &ch);
	     }
	push(&s, ch);
	push(&s, eq[i]);
	}
else posteq[++postlength] = eq[i];
while(pop(&s, &ch))
     posteq[++postlength] = ch;
posteq[postlength] = '\0';
}

void main()
{
char eq[100], posteq[100];
gets(eq);
convpost(eq, posteq);
puts(posteq);
}
