//Polynomial addition and subtraction
#include<stdio.h>
#include<stdlib.h>

typedef struct node
{   int coef;
    int pow;
    struct node *next;
}poly;

 
void sort(poly *head)
{   
    poly *iptr, *jptr;
    if(head==NULL)return;
    for(iptr = head; iptr->next; iptr=iptr->next)
       for(jptr = iptr->next; jptr; jptr=jptr->next)
	  if(iptr->pow < jptr->pow)
	    {int temp = iptr->pow;
	     iptr->pow = jptr->pow;
	     jptr->pow = temp;
	     temp = iptr->coef;
	     iptr->coef = jptr->coef;
	     jptr->coef= temp;
	    }
}

poly * create()
{   int n, i;
    poly *newnode, *last, *head = NULL;
    printf("\n\tEnter number of terms: ");
    scanf("%d",&n);
    for(i=1; i<= n; i++)
    {   newnode=(poly *)malloc(sizeof(poly));
	clrscr();
	printf("\n\tEnter coefficent of term no %d: ",i);
	scanf("%d",&newnode->coef);
	printf("\n\tEnter power of term no %d: ",i);
	scanf("%d",&newnode->pow);
	newnode->next = NULL;
	if(head == NULL)
	  head = newnode;
	else last->next = newnode;
	last = newnode;
    }
    sort(head);
    return head;
}

void display (poly *head)
{   poly * temp = head;
    if(temp==NULL)
	printf("\n\tEmpty\n");
    else
    {while(temp)
	{ if(temp->pow==0)
		 printf("%+d",temp->coef);
	  else if(temp->pow==1)
		  printf("%+dx",temp->coef);
	       else printf("%+dx^%d",temp->coef,temp->pow);
	  temp = temp->next;
	}
    }
}

 
poly *add (poly *head1,poly *head2)
{   
    poly *newnode, *head3=NULL, *last;
    poly *curr1=head1, *curr2=head2;
    while(curr1||curr2)
    {
	newnode=(poly *)malloc(sizeof(poly));
	newnode->next=NULL;
	if(curr1==NULL&&curr2!=NULL)
	  {
	    newnode->coef=curr2->coef;
	    newnode->pow=curr2->pow;
	    curr2=curr2->next;
	  }
	else if(curr2==NULL&&curr1!=NULL)
	       {
		newnode->coef=curr1->coef;
		newnode->pow=curr1->pow;
		curr1=curr1->next;
	       }
	     else if(curr1->pow>curr2->pow)
		    {
		     newnode->coef=curr1->coef;
		     newnode->pow=curr1->pow;
		     curr1=curr1->next;
		    }
		  else if(curr1->pow<curr2->pow)
			 {
			  newnode->coef=curr2->coef;
			  newnode->pow=curr2->pow;
			  curr2=curr2->next;
			 }
		       else {
			     newnode->coef=curr1->coef+curr2->coef;
			     newnode->pow=curr2->pow;
			     curr1=curr1->next;
			     curr2=curr2->next;
			    }
	if(head3 == NULL)
	  head3 = newnode;
	else last->next = newnode;
	last = newnode;
    }
    return head3;
}

poly *sub (poly *head1,poly *head2)
{
    poly *newnode, *head3=NULL, *last;
    poly *curr1=head1, *curr2=head2;
    while(curr1||curr2)
    {
	newnode=(poly *)malloc(sizeof(poly));
	newnode->next=NULL;
	if(curr1==NULL&&curr2!=NULL)
	  {
	    newnode->coef=curr2->coef;
	    newnode->pow=curr2->pow;
	    curr2=curr2->next;
	  }
	else if(curr2==NULL&&curr1!=NULL)
	       {
		newnode->coef=curr1->coef;
		newnode->pow=curr1->pow;
		curr1=curr1->next;
	       }
	     else if(curr1->pow>curr2->pow)
		    {
		     newnode->coef=curr1->coef;
		     newnode->pow=curr1->pow;
		     curr1=curr1->next;
		    }
		  else if(curr1->pow<curr2->pow)
			 {
			  newnode->coef=curr2->coef;
			  newnode->pow=curr2->pow;
			  curr2=curr2->next;
			 }
		       else {
			     newnode->coef=curr1->coef-curr2->coef;
			     newnode->pow=curr2->pow;
			     curr1=curr1->next;
			     curr2=curr2->next;
			    }
	if(head3 == NULL)
	  head3 = newnode;
	else last->next = newnode;
	last = newnode;
    }
    return head3;
}


void main()
{   int ch;
    poly *head1 = NULL, *head2 = NULL, *head3 = NULL;
    do
    {
    clrscr();
    printf("\n\t1)Create 1st Polynomial ");
    printf("\n\t2)Create 2nd Polynomial ");
    printf("\n\t3)Display");
    printf("\n\t4)Add Polynomials");
    printf("\n\t5)Subtract Polynomials");
    printf("\n\t6)Quit");
    printf("\n\tEnter your choice:");
    scanf("%d",&ch);
    switch(ch)
    {case 1: head1 = create(); break;
     case 2: head2 = create(); break;
     case 3: printf("\n\t1'st Polynomial\t\t");
	     display(head1);
	     printf("\n");
	     printf("\n\t2'nd Polynomial\t\t");
	     display(head2);
	     break;
     case 4: head3 = add(head1,head2);
	     printf("\n\t1'st Polynomial\t\t");
	     display(head1);
	     printf("\n\t2'nd Polynomial\t\t");
	     display(head2);
	     printf("\n\tAddition\t\t");
	     display(head3);
	     break;
     case 5: head3 = sub(head1,head2);
	     printf("\n\t1'st Polynomial\t\t");
	     display(head1);
	     printf("\n\t2'nd Polynomial\t\t");
	     display(head2);
	     printf("\n\tSubtraction\t\t");
	     display(head3);
	     break;
     }
     getch();
     }while(ch != 6);
}
