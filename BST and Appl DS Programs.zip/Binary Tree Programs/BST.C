#include <stdio.h>
#include <conio.h>

typedef struct node
{int data;
 struct node *left, *right;
}node;

int search(node *root, int no, node **posptr, node **prevptr)
{*posptr = root;
 *prevptr = NULL;
 while(*posptr)
      {if((*posptr)->data == no)return 1;
       *prevptr = *posptr;
       if((*posptr)->data < no)
	 *posptr = (*posptr)->right;
       else *posptr = (*posptr)->left;
      }
 return 0;
}
int add(node **rootptr, int no)
{node *p, *pos, *prev;
 if(search(*rootptr, no, &pos, &prev)==1)return 0;
 p = (node *) malloc (sizeof(node));
 if(p==NULL)return 0;
 p->data = no;
 p->left = p->right = NULL;
 if(prev == NULL)
   *rootptr = p;
 else if(prev->data < no)
	 prev->right = p;
      else prev->left = p;
 return 1;
}
void inorder(node *root)
{if(root)
      {inorder(root->left);
       printf("%d  ", root->data);
       inorder(root->right);
      }
}
void preorder(node *root)
{if(root)
      {printf("%d  ", root->data);
       preorder(root->left);
       preorder(root->right);
      }
}
void postorder(node *root)
{if(root)
      {
       postorder(root->left);
       postorder(root->right);
       printf("%d  ", root->data);
      }
}
int nodecount (node *root)
{if(root==NULL)return 0;
 return 1 + nodecount(root->left) + nodecount(root->right);
}

int leafnodecount (node *root)
{if(root==NULL)return 0;
 if(root->left==NULL && root->right==NULL)return 1;
 return leafnodecount(root->left) + leafnodecount(root->right);
}
int deletion (node **rootptr, int no)
{node *temp, *pos, *prev;
 if(!search(*rootptr, no, &pos, &prev))return 0;
 if(pos->left == NULL)              //No left subtree
   if(prev==NULL)                  //No left subtrre and root node
     *rootptr = pos->right;
   else if(prev->left == pos)      //No left subtree and non-root node
	  prev->left = pos->right;
	else prev->right = pos->right;
 else if(pos->right==NULL)            //No right subtree
	if(prev==NULL)               // No right subtree and root node
	  *rootptr = pos->left;
	else if(prev->left == pos)   //No right subtree and non root node
	       prev->left = pos->left;
	     else prev->right = pos->left;
      else{temp= pos->right;          //general node with both subtrees
	    while(temp->left)
		  temp = temp->left;
	   temp->left = pos->left;
	   if(prev==NULL)               //general node and root node
	     *rootptr = pos->right;
	   else if(prev->left == pos)   //general and non-root node
		  prev->left = pos->right;
		else prev->right = pos->right;
	  }
 free(pos);
 return 1;
}

void main()
{int choice, n, i, no;
 node *p, *prev, *root = NULL;
 clrscr();
 printf("\nCreation of Binary Tree\n");
 printf("How many nodes: ");
 scanf("%d", &n);
 for(i = 1; i <= n; i++)
    {printf("Enter the no: ");
     scanf("%d", &no);
     add(&root, no);
    }
 do
 {
 clrscr();
 printf("Binary tree of %d nodes created\n");
 printf("Enter 1 to search a no\n");
 printf("Enter 2 to add a no\n");
 printf("Enter 3 to delete a no\n");
 printf("Enter 4 to count no of nodes in the tree\n");
 printf("Enter 5 to count no of nodes in the tree\n");
 printf("Enter 6 to print the tree inorder\n");
 printf("Enter 7 to print the tree preorder\n");
 printf("Enter 8 to print the tree postorder\n");
 printf("Enter 9 to quit\n");
 printf("Enter your choice: ");
 scanf("%d", &choice);
 switch(choice)
 {case 1: printf("Enter the no to be searched: ");
	  scanf("%d", &no);
	  if(search(root, no, &p, &prev))
	    printf("No present in the tree\n");
	  else printf("No not present in the tree\n");
	  break;
  case 2: printf("Enter the no to be added: ");
	  scanf("%d", &no);
	  if(add (&root, no))
	    printf("No added in the tree\n");
	  else printf("No already present in the tree\nCannot add\n");
	  break;
  case 3: printf("Enter the no to be deleted: ");
	  scanf("%d", &no);
	  if(deletion(&root, no))
	    printf("No deleted from the tree\n");
	  else printf("No not present in the tree\nCannot delete\n");
	  break;
   case 4:printf("No of nodes in the tree are %d\n", nodecount(root));
	  break;
   case 5:printf("No of leaf nodes in the tree are %d\n", leafnodecount(root));
	  break;
   case 6:printf("Inorder traversal is:\n");
	  inorder(root);
	  break;
   case 7:printf("Preorder traversal is:\n");
	  preorder(root);
	  break;
   case 8:printf("Postorder traversal is:\n");
	  postorder(root);
	  break;
  }
 getch();
 }while(choice != 9);
}