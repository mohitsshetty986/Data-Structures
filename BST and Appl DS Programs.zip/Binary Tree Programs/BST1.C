//Recursive Functions

#include <stdio.h>
#include <conio.h>

typedef struct node
{int data;
 struct node *left, *right;
}node;

node * search(node *root, int no) //recursive search
{node *p = root;
 if(p==NULL)return p;
 if(p->data==no)return p;
 if(p->data > no)return search(p->left, no);
 return search(p->right, no);
}

int add(node **rootptr, int no)    //recursive addition
{if(*rootptr==NULL)
   {node *p = (node *) malloc(sizeof(node));
    if(p==NULL)return 0;
    p->data = no;
    p->left = p->right = NULL;
    *rootptr = p;
    return 1;
   }
 if((*rootptr)->data == no)return 0;
 if((*rootptr)->data > no) return add(&(*rootptr)->left, no);
 return add(&(*rootptr)->right, no);
}

int deletion (node **rootptr, int no)  //recursive deletion
{node *p = *rootptr;
 if(p==NULL)return 0;
   if(p->data > no)
     return deletion(&p->left, no);
   else if(p->data < no)
	   return deletion(&p->right, no);
	else if(p->left==NULL)
	       {*rootptr = p->right;
		free(p); return 1;
	       }
	     else if(p->right == NULL)
		    {*rootptr = p->left;
		     free(p); return 1;
		    }
		  else {p = p->left;
			while(p->right)
			      p = p->right;
			(*rootptr)->data = p->data;
			return deletion (&(*rootptr)->left, p->data);
		       }
}

void inorder(node *root)
{
 if(root)
   {inorder(root->left);
    printf("%d  ", root->data);
    inorder(root->right);
   }
}
void preorder(node *root)
{
 if(root)
   {printf("%d  ", root->data);
    preorder(root->left);
    preorder(root->right);
   }
}
void postorder(node *root)
{
 if(root)
   {postorder(root->left);
    postorder(root->right);
    printf("%d  ", root->data);
   }
}
int nodecount (node *root)
{if(root==NULL)return 0;
 return 1 + nodecount(root->left) + nodecount(root->right);
}

int leafnodecount (node *root)
{if(root==NULL)return 0;
 if(root->left==NULL && root->right==NULL)return 1;
 return leafnodecount(root->left) + leafnodecount(root->right);
}

void main()
{int choice, n, i, no;
 node *root = NULL;
 clrscr();
 printf("\nCreation of Binary Tree\n");
 printf("How many nodes: ");
 scanf("%d", &n);
 for(i = 1; i <= n; i++)
    {printf("Enter the no: ");
     scanf("%d", &no);
     add(&root, no);
    }
 do
 {
 clrscr();
 printf("Binary tree of %d nodes created\n");
 printf("Enter 1 to search a no\n");
 printf("Enter 2 to add a no\n");
 printf("Enter 3 to delete a no\n");
 printf("Enter 4 to count no of nodes in the tree\n");
 printf("Enter 5 to count no of nodes in the tree\n");
 printf("Enter 6 to print the tree inorder\n");
 printf("Enter 7 to print the tree preorder\n");
 printf("Enter 8 to print the tree postorder\n");
 printf("Enter 9 to quit\n");
 printf("Enter your choice: ");
 scanf("%d", &choice);
 switch(choice)
 {case 1: printf("Enter the no to be searched: ");
	  scanf("%d", &no);
	  if(search(root, no))
	    printf("No present in the tree\n");
	  else printf("No not present in the tree\n");
	  break;
  case 2: printf("Enter the no to be added: ");
	  scanf("%d", &no);
	  if(add (&root, no))
	    printf("No added in the tree\n");
	  else printf("No already present in the tree\nCannot add\n");
	  break;
  case 3: printf("Enter the no to be deleted: ");
	  scanf("%d", &no);
	  if(deletion(&root, no))
	    printf("No deleted from the tree\n");
	  else printf("No not present in the tree\nCannot delete\n");
	  break;
   case 4:printf("No of nodes in the tree are %d\n", nodecount(root));
	  break;
   case 5:printf("No of leaf nodes in the tree are %d\n", leafnodecount(root));
	  break;
   case 6:printf("Inorder traversal is:\n");
	  inorder(root);
	  break;
   case 7:printf("Preorder traversal is:\n");
	  preorder(root);
	  break;
   case 8:printf("Postorder traversal is:\n");
	  postorder(root);
	  break;
  }
 getch();
 }while(choice != 9);
}