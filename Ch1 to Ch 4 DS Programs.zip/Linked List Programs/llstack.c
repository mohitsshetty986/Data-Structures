//Stack using LIFO Linked List

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
typedef int stackelement;

typedef
struct node
{stackelement data;
 struct node *next;
}node;

typedef struct
{node *top;
}stacktype;

void initialise(stacktype *sptr)
{sptr->top = NULL;}

int push(stacktype *sptr, stackelement no)
{node *p;
 p = (node*) malloc(sizeof(node));
 if(p==NULL) return 0;
 p->data = no;
 p->next = sptr->top;
 sptr->top = p;
 return 1;
}

int pop(stacktype *sptr, stackelement *noptr)
{node *p = sptr->top;
 if(p==NULL) return 0;
 *noptr = p->data;
 sptr->top = p->next;
 free(p);
 return 1;
}

void printstack(stacktype s)
{node *p = s.top;
 if(p == NULL)
    printf("Empty Stack\n");
 else {printf("The Current Stack is:\n");
       while(p)
	    {printf("%d\n", p->data);
	     p = p->next;
	    }
      }
}

 
void main()
{stacktype st;
 stackelement no;
 int choice;
 initialise(&st);
 do
 { clrscr();
   printf("Enter 1 to Push\n");
   printf("Enter 2 to Pop\n");
   printf("Enter 3 to quit\n");
   printf("Enter your choice: ");
   scanf("%d", &choice);
   switch(choice)
   {case 1: printf("Enter no: ");
	    scanf("%d", &no);
	    push(&st, no);
	    printstack(st); break;
    case 2: if(pop(&st, &no))
	      printf("No popped = %d\n", no);
	    printstack(st); break;
   }
   getch();
}while(choice != 3);
}
