//Priority Queue with normal addition using Linked List

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

typedef int qelement;

typedef struct node
{ 
  qelement data;
  node *next;
} node;

typedef struct
{ node *first;}qtype;

void initialise(qtype *qptr)
{
qptr->first = NULL;
}

 
int addq(qtype *qptr, qelement no)
{
node *p;
p = (node*) malloc(sizeof(node));
if(p == NULL) return 0;
p->data = no;
p->next = qptr->first;
qptr->first = p;
return 1;
}

int delq (qtype *qptr, qelement *noptr)
{
node *p = qptr->first, *prev = NULL, *iptr, *jptr;
if (p== NULL)return 0;
for(iptr= p->next, jptr = p; iptr; jptr = iptr, iptr= iptr->next)
   if(iptr->data > p->data)
     {p = iptr; prev = jptr;}
*noptr = p->data;
if(prev == NULL)qptr->first = p->next;
else prev->next = p->next;
free (p);
return 1;
}

void display(qtype que)
{
node *p = que.first;
if (p == NULL)
   printf("Empty List\n");
else {printf("Current queue is: \n");
      while(p)
	   {printf("%d  ", p->data); p=p->next;}
      }
getch();
}

void main()
{int choice;
qtype q;
qelement no;
initialise(&q);
do
{clrscr();
printf("Enter 1 for ADD\n");
printf("Enter 2 for DELETE\n");
printf("Enter 3 for Display\n");
printf("Enter 4 to QUIT\n");
printf("Enter your choice: ");
scanf("%d", &choice);
switch (choice)
{ case 1 :      printf("Enter the No: ");
		scanf("%d", &no);
		addq(&q, no);
		display(q);
		break;
  case 2 :      if(delq(&q, &no))
		  printf("No deleted: %d\n", no);
		display(q);
		break;
  case 3 :      display(q);
		break;
}
}while (choice != 4);
}
