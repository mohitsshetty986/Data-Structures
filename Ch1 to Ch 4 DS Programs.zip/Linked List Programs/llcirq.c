//Queue using Circular Linked List

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

typedef int qelement;

typedef struct node
{ 
 qelement data;
  node *next;
} node;

typedef struct
{
 node *last;
}qtype;

void initialise(qtype *qptr)
{qptr->last = NULL;}

int addq(qtype *qptr, qelement no)
{node *p;
p = (node*) malloc(sizeof(node));
if(p == NULL) return 0;
p->data = no;
if(qptr->last == NULL) p->next = p;
else  {p->next = qptr->last->next;
       qptr->last->next = p;
      }
qptr->last = p;
return 1;
}

int delq (qtype *qptr, qelement *noptr)
{node *p = qptr->last;
if (p== NULL)return 0;
p = p->next;
*noptr = p->data;
if(p == p->next) qptr->last = NULL;
else qptr->last->next = p->next;
free (p);
return 1;
}

void display(qtype que)
{node *p = que.last;
if (p == NULL)
   printf("Empty List\n");
else {printf("Current queue is: \n");
      p =p->next;
      do{
	 printf("%d  ", p->data);
	 p=p->next;
	 }
      while(p != que.last->next);
      }
getch();
}

void main()
{int choice;
qtype q;
qelement no;
initialise(&q);
do
{
clrscr();
printf("Enter 1 for ADD\n");
printf("Enter 2 for DELETE\n");
printf("Enter 3 for Display\n");
printf("Enter 4 to QUIT\n");
printf("Enter your choice: ");
scanf("%d", &choice);
switch (choice)
{ case 1 :      printf("Enter the No: ");
		scanf("%d", &no);
		addq(&q, no);
		display(q);
		break;
  case 2 :      if(delq(&q, &no))
		  printf("No deleted: %d\n", no);
		display(q);
		break;
  case 3 :      display(q);
		break;
}
}while (choice != 4);
}

