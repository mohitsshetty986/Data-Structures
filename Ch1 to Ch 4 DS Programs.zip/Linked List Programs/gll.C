//This program creates a linked list of n nodes, prints it in normal
// and reverse order and then reveses it and splits it in two linked lists
//one with even nos and one with odd nos.

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

typedef struct nd
{ int data;
  struct nd *next;
} node;


int create (node **firstptr, int n)
{   node *p, *last;
    int i;
    for(i = 1; i <= n; i++)
	{p=(node *) malloc (sizeof(node));
	 if(p==NULL) return 0;
	 printf("Enter an integer: ");
	 scanf("%d", &p->data);
	 p->next=NULL;
	 if(i == 1)
	    *firstptr = p;
	 else last->next = p;
	 last = p;
	}
    return 1;
}


void print(node *first)
{    node *p = first;
     if(p==NULL)
	printf("\nLinked List is Empty");
     else { printf("\nCurrent Linked List is:");
	    while(p)
	    { printf("%d ",p->data);
	      p=p->next;
	    }
	  }
     getch();
}


void revprint(node *first)
{if(first)
   {revprint(first->next);
    printf("%d  ", first->data);
   }
}

int count (node *first)
{ node *p = first;
 int count = 0;
 while(p)
	{count++;
	 p = p->next;
	}
return count;
}

void reverse (node **firstptr)
{
 node *ptr = *firstptr, *prev = NULL, *r;
while(ptr)
	{r = ptr->next;
	 ptr->next = prev;
	 prev = ptr;
	 ptr = r;
	}
*firstptr = prev;
}

int split (node **pptr, node **p1ptr, node **p2ptr)
{
 node *last1, *last2;
 *p1ptr = NULL, *p2ptr = NULL;
 while(*pptr)
     {node *p = *pptr;
      *pptr = p->next;
      p->next = NULL;
      if(p->data%2==0)
	{if(*p1ptr==NULL)
	   *p1ptr = p;
	 else last1->next = p;
	 last1 = p;
	}
      else {if(*p2ptr==NULL)
	      *p2ptr = p;
	    else last2->next = p;
	   last2 = p;
	   }
      p = *pptr;
     }
 return 1;
}
void main()
{int n;
 node *p, *p1, *p2;
 clrscr();
 printf("How many nodes: ");
 scanf("%d", &n);
 create(&p, n);
 print(p);
 printf("\nThe linked list in reverse order is:\n");
 revprint(p);
 printf("\nThe no of nodes is the list are %d\n", count(p));
 reverse(&p);
 print(p);
 split(&p, &p1, &p2);
 printf("\nThe even nodes are:");
 print(p1);
 printf("\nThe odd nodes are:");
 print(p2);
 getch();
}
