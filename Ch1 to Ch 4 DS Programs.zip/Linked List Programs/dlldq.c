//Linear deque with double linked list

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

typedef int qelement;
typedef struct node
{ qelement data;
  node *next, *prev;
} node;

typedef struct
{ node *left, *right;
} dqtype;

void initialise(dqtype *qptr)
{qptr->left = qptr->right = NULL;}

int addleft(dqtype *qptr, qelement no)
{
node *p;
p = (node*) malloc(sizeof(node));
if(p == NULL)return 0;
p->data = no; p->next = qptr->left; p->prev = NULL;
if(qptr->left == NULL)qptr->right = p;
else qptr->left ->prev = p;
qptr->left = p;
return 1;
}

int addright(dqtype *qptr, qelement no)
{
node *p;
p = (node*) malloc(sizeof (node));
if(p==NULL)return 0;
p->data = no; p->prev = qptr->right; p->next = NULL;
if(qptr->right == NULL)qptr->left = p;
else qptr->right->next = p;
qptr->right = p;
return 1;
}

int delleft(dqtype *qptr, qelement *noptr)
{
node *p = qptr->left;
if (p == NULL) return 0;
*noptr = p->data;
if(qptr->left == qptr->right){qptr->left = qptr->right = NULL;}
else qptr->left = p->next;
qptr->left->prev = NULL;
free(p);
return 1;
}
int delright(dqtype *qptr, qelement *noptr)
{
node *p = qptr->right;
if (p == NULL) return 0;
*noptr = p->data;
if(qptr->left == qptr->right){qptr->left = qptr->right = NULL;}
else qptr->right = p->prev;
qptr->right->next = NULL;
free(p);
return 1;
}

void printdq(dqtype dq)
{if (dq.left== NULL) printf("DQ is empty\n");
else while (dq.left)
	   {printf("%d ", dq.left->data);
	    dq.left = dq.left->next;
	   }
}

void main()
{
dqtype dq;
int choice;
qelement no;
initialise (&dq);
do
{
clrscr();
start : printf("Enter 1 to add left\n");
	printf("Enter 2 to add right\n");
	printf("Enter 3 to delete left\n");
	printf("Enter 4 to delete right\n");
	printf("Enter 5 to print\n");
	printf("Enter 6 to quit\n");
	printf("Enter choice: ");
	scanf("%d", &choice);
	switch(choice)
		{
		case 1: printf ("Enter no: ");
			scanf("%d", &no);
			if(!addleft(&dq, no))
			printf ("Cannot Add\n");
			printdq(dq);
			break;
		case 2: printf ("Enter no: ");
			scanf("%d", &no);
			if(!addright(&dq, no))
			printf ("Cannot Add\n");
			printdq(dq);
			break;
		case 3: if (!delleft(&dq, &no))
			     printf ("Cannot delete\n");
			else printf ("No deleted = %d\n", no);
			printdq(dq);
			break;
		case 4: if (!delright(&dq, &no))
			     printf ("Cannot delete\n");
			else printf ("No deleted = %d\n", no);
			printdq(dq);
			break;
		case 5: printdq(dq);
			break;
		}
		printf("Press a key to continue\n");
		getch();
}while (choice != 6);
}
