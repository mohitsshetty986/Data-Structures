//This program concatenates two linked lists
//and creates a copy of linked list
#include <stdio.h>
#include <conio.h>

typedef struct node
{int data;
 struct node *next;
}node;

void printlist(node *p)
{while(p)
      {printf("%d  ", p->data);
       p = p->next;
      }
 printf("\n");
}
int createlist(int n, node **firstptr)
{node *last, *p;
 int i;
 *firstptr = NULL;
 for(i = 1; i<= n; i++)
    {p = (node *) malloc(sizeof(node));
     if(p==NULL)return 0;
     printf("Enter data: ");
     scanf("%d", &p->data);
     p->next = NULL;
     if(*firstptr==NULL)
       *firstptr = p;
     else last->next = p;
     last = p;
    }
 return 1;
}

void concat(node **p1ptr, node *p2)
{node* p = *p1ptr;
 if(p==NULL)
   *p1ptr = p2;
 else {while(p->next)
	    p = p->next;
       p->next = p2;
      }
}

int copy(node *p, node **p1ptr)
{node *q, *last;
 *p1ptr = NULL;
 while(p)
 { q = (node *) malloc(sizeof(node));
   if(q==NULL)return 0;
   q->data = p->data;
   if(*p1ptr==NULL)
     *p1ptr = q;
   else last->next = q;
   last = q;
   p = p->next;
 }
 return 1;
}


void main()
{node *p1, *p2, *p3, *p;
 int i, j, n;
 clrscr();
 for(j = 1; j<=2; j++)
    { printf("\nLinked list No %d\nHow many nodes: ", j);
      scanf("%d", &n);
      if(j==1)
	createlist(n, &p1);
      else createlist(n, &p2);
      printf("Linked List No %d is: ", j);
      if(j==1)
	printlist(p1);
      else printlist(p2);
    }
 concat(&p1, p2);
 printf("\nConcatenated list is: ");
 printlist(p1);
 copy(p1, &p3);
 printf("\nConcatenated list is: ");
 printlist(p3);
 getch();
}