//This progrm creates, sort a single linked list and also
//searches, adds to and deletes from the sorted linked list
#include<stdio.h>
#include<conio.h>

typedef int listelement;

typedef struct node
{
 listelement data;
 struct node *next;
}node;

int create (node **firstptr, int n)
{   node *p, *last;
    int i;
    for(i = 1; i <= n; i++)
	{p=(node *) malloc (sizeof(node));
	 if(p==NULL) return 0;
	 printf("Enter an integer: ");
	 scanf("%d", &p->data);
	 p->next=NULL;
	 if(i == 1)
	    *firstptr = p;
	 else last->next = p;
	 last = p;
	}
    return 1;
}
void sort(node *first)
{node *iptr, *jptr;
 for(iptr = first; iptr->next; iptr=iptr->next)
    for(jptr= iptr->next; jptr; jptr=jptr->next)
	if(iptr->data > jptr->data)
	  {listelement temp;
	   temp = iptr->data;
	   iptr->data = jptr->data;
	   jptr->data = temp;
	  }
 return;
}
int del(node **firstptr, listelement no)
{
    node *p = *firstptr, *prev = NULL;
    while(p)
    { if(p->data == no)break;
      prev = p;
      p = p->next;
    }
    if(p==NULL) return 0;
    if(prev==NULL)
      *firstptr = p->next;
    else prev->next = p->next;
    free(p);
    return 1;
}
int add(node **firstptr, listelement no)
{   node *p = *firstptr, *prev = NULL;
    node *q = (node *) malloc(sizeof(node));
    if(q==NULL)return 0;
    q->data = no;
    while(p)
    { if(p->data > no)break;
      prev = p;
      p = p->next;
    }
    q->next = p;
    if(prev==NULL)
      *firstptr = q;
    else prev->next = q;
    return 1;
}
void revprint(node *p)
{ if(p == NULL)return;

  revprint(p->next);
  printf("%d  ", p->data);
}

void print(node *first)
{
     node *p = first;
     if(p==NULL)
	printf("Linked List is Empty");
     else { printf("Current Linked List is:");
	    while(p)
	    {
	     printf("%d ",p->data);
	     p=p->next;
	    }
	  }
     getch();
}

int search(node *first, listelement no)
{node *p = first;
 while(p)
      {if(p->data == no)
	 return 1;
       else p = p->next;
      }
 return 0;
}

void main()
{int choice;
node *first;
listelement no;
int pos;
clrscr();
create(&first, 4);
sort(first);
print(first);
do
{clrscr();
printf("\t\tMAIN MENU\n");
printf("Enter 1 to Add\n");
printf("Enter 2 to Delete\n");
printf("Enter 3 to Display\n");
printf("Enter 4 to Search\n");
printf("Enter 5 to Quit\n");
printf("Enter your choice: ");
scanf("%d", &choice);
switch (choice)
{ case 1 :printf("Enter the No: ");
	  scanf("%d", &no);
	  add(&first, no);
	  print(first);
	  break;
  case 2 :printf("Enter the No: ");
	  scanf("%d", &no);
	  if(del(&first, no))
	    printf("No deleted: %d\n", no);
	  else printf("No not found\n");
	  print(first);
	  break;
  case 3 :print(first);
	  printf("\nThe Linked list in reversed order is:\n");
	  revprint(first);
	  getch();
	  break;
  case 4: printf("Enter the No to be searched: ");
	  scanf("%d", &no);
	  if(search(first, no))
	    printf("No is present\n");
	  else printf("No is not present\n");
	  getch();
}
}while (choice != 5);
}


