#include <stdio.h>
#include <conio.h>

void swap(int *xptr, int *yptr)
{int temp = *xptr;
     *xptr = *yptr;
     *yptr = temp;
}

void main()
{int  a = 20, b = 30;
 void swap(int *, int *);
 clrscr();
 printf("a = %d\tb = %d\n", a, b);
 swap(&a, &b);
 printf("a = %d\tb = %d\n", a, b);
 getch();
}