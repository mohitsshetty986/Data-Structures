#include <stdio.h>
#include <conio.h>

void main()
{int n, no, i, count;
 short prime(int);
 clrscr();
 printf("How many prime nos: ");
 scanf("%d", &n);
 no = 2;
 count = 0;
 while(count < n)
      {if(prime(no))
	  {printf("%d  ", no);
	   count++;
	  }
	no++;
      }
 getch();
}

short prime(int no)
{int i = 2;
 while(no%i != 0)
      i++;
 return (no ==i);
}