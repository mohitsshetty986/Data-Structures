#include <stdio.h>
#include <conio.h>

void main()
{int no;
 short prime(int);
 short fibo(int);
 clrscr();
 printf("Enter the integer: ");
 scanf("%d", &no);
 while(no >= 0)
      {if(prime(no))
	 if(fibo(no))
	   printf("Prime and Fibo No\n");
	 else printf("Only Prime No\n");
       else if(fibo(no))
	      printf("Only Fibo No\n");
	    else printf("Neither Prime Nor Fibo No\n");
       printf("Enter the integer: ");
       scanf("%d", &no);
      }
 getch();
}

short prime(int no)
{int i = 2;
 while(no%i != 0)
      i++;
 return (no ==i);
}
short fibo(int no)
{int first = 1, second = 1, third = 1;
 while(third < no)
      {third = first + second;
       first = second;
       second = third;
      }
 return third == no;
}