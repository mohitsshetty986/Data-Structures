#include <stdio.h>
#include <conio.h>

void deletion (int a[], int *nptr, int no)
{int i, j, m = *nptr;
 for(i=0; i<m; i++)
    if(a[i] == no)
      {for(j = i; j < m-1; j++)
	  a[j] = a[j+1];
       m--; i--;
      }
 *nptr = m;
}
void main()
{int x[100], n, no,i;
 clrscr();
 printf("How many elements: ");
 scanf("%d", &n);
 printf("Emter the elements: ");
 for(i =0; i < n; i++)
    scanf("%d", &x[i]);
 printf("Enter the no to be deleted: ");
 scanf("%d", &no);
 deletion(x, &n, no);
 printf("The new array is:\n");
 for(i=0; i < n; i++)
    printf("%d ", x[i]);
 printf("\n");
 getch();
}