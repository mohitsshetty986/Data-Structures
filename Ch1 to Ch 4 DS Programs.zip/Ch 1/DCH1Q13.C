#include <stdio.h>
#include <conio.h>
typedef struct
{float real, imag;
}complex;
complex read1()
{complex x;
 printf("Enter real and Imaginary parts: ");
 scanf("%f %f", &x.real, &x.imag);
 return x;
}
void read2(complex *xptr)
{printf("Enter real and Imaginary parts: ");
 scanf("%f %f", &xptr->real, &xptr->imag);
}
complex add(complex x, complex y)
{complex z;
 z.real = x.real + y.real;
 z.imag = x.imag + y.imag;
 return z;
}
void sub(complex x, complex y, complex *zptr)
{
 zptr->real = x.real - y.real;
 zptr->imag = x.imag - y.imag;
}
void mult(complex x, float y, float z, complex *uptr)
{
 uptr->real = x.real * y - x.imag * z;
 uptr->imag = x.imag * y + x.real * z;
}

void print(complex x)
{
 printf("%g%+gi\n", x.real, x.imag);
}
void main()
{complex a, b, c, d, e;
 clrscr();
 a = read1();
 read2(&b);
 c = add(a, b);
 sub(a, b, &d);
 mult(a, b.real, b.imag, &e);
 print(c);
 print(d);
 print(e);
 getch();
}