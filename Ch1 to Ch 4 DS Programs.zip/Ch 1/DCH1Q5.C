#include <stdio.h>
#include <conio.h>

void main()
{int n, no, i, count;
 short prime(int);
 clrscr();
 printf("Enter the integer: ");
 scanf("%d", &n);
 for(no = 2; no <= n; no++)
    if(prime(no))
      printf("%d  ", no);
 getch();
}

short prime(int no)
{int i = 2;
 while(no%i != 0)
      i++;
 return (no ==i);
}