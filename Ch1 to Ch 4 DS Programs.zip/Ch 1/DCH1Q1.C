#include <stdio.h>
#include <conio.h>

void main()
{char ch;
 clrscr();
 printf("Char\tASCII\tOctal\tHexa\n\n");
 for(ch = 'A'; ch <= 'Z'; ch++)
    {printf("%c\t%d\t%o\t%x\n", ch, ch, ch, ch);
     if(ch=='M')getch();
    }
 getch();
}