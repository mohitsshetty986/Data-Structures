#include <stdio.h>
#include <conio.h>
#define MAX 100

void main()
{float mean(int[], int);
 float median(int[], int);
 int x[MAX], n, i;
 clrscr();
 printf("How many elements: ");
 scanf("%d", &n);
 printf("Enter the elements: ");
 for(i = 0; i < n; i++)
    scanf("%d", &x[i]);
 printf("Mean = %g\n", mean(x, n));
 printf("Median = %g\n", median(x, n));
 getch();
}
float mean(int a[], int n)
{int sum = 0;
 int i;
 for(i = 0; i < n; i++)
     sum += a[i];
 return (float) sum / n;
}
float median(int b[], int n)
{int i, j, small, pos;
 for(j = 0; j < n-1; j++)
    {small = b[j];
     pos = j;
     for(i = j+1; i < n; i++)
	if(b[i] < small)
	  {small = b[i];
	   pos = i;
	  }
     b[pos] = b[j];
     b[j] = small;
    }
 if(n%2==0)return (b[n/2]+b[n/2-1])/2.0;
 return b[n/2];
}

