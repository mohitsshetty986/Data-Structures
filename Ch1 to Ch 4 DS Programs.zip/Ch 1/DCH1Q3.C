#include <stdio.h>
#include <conio.h>

void main()
{int no, i;
 clrscr();
 printf("Enter an integer: ");
 scanf("%d", &no);
 i = 2;
 while(no%i != 0)
      i++;
 if(no ==i)
   printf("Prime No\n");
 else printf("Not a Prime No\n");
 getch();
}