#include <stdio.h>
#include <conio.h>

void main()
{char str[100];
 int i, j;
 clrscr();
 printf("Emter the string: ");
 gets(str);
 i=0;
 for(j = 0; str[j]; j++);
 for(j--; i < j; i++, j--)
    if(str[i] != str[j])
      break;
 if(i >= j)
   printf("Palindrome\n");
 else printf("Not a Palindrome\n");
 getch();
}