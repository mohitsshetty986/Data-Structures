#include <stdio.h>
#include <conio.h>

void main()
{long reverse(int);
 int no;
 clrscr();
 printf("Enter an integer: ");
 scanf("%d", &no);
 printf("The reversed no is %ld\n", reverse(no));
 getch();
}
long reverse(int no)
{long rev = 0;
 while(no)
     {short dig = no % 10;
      rev = rev*10 + dig;
      no = no / 10;
     }
 return rev;
}
