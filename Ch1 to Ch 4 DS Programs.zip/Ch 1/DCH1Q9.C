#include <stdio.h>

#include <conio.h>

void sort(int a[], int m)
{int i, j, temp;
 for(i=1; i<m; i++)
    for(j = 0; j < m-i; j++)
       if(a[j] > a[j+1])
	 {int temp = a[j];
	  a[j] = a[j+1];
	  a[j+1] = temp;
	 }
 printf("The sorted array is:\n");
 for(i=0; i < m; i++)
    printf("%d ", a[i]);
 printf("\n");
}
void main()
{int x[100], y[100], n, i;
 clrscr();
 printf("How many elements: ");
 scanf("%d", &n);
 printf("Emter the elements: ");
 for(i =0; i < n; i++)
    {scanf("%d", &x[i]);
     y[i] = x[i];
    }
 sort(y, n);
 printf("The original array is:\n");
 for(i=0; i < n; i++)
    printf("%d ", x[i]);
 printf("\n");
 getch();
}