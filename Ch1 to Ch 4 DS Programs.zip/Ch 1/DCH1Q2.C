#include <stdio.h>
#include <conio.h>

void main()
{float no;
 clrscr();
 printf("Enter a number: ");
 scanf("%f", &no);
 if(no < 0)
   printf("No Data\n");
 else {float max = no, min = no, sum = no;
       int count = 1;
       printf("Enter a number: ");
       scanf("%f", &no);
       while(no >= 0)
	    {if(no > max)
	       max = no;
	     else if(no < min)
		    min = no;
	     sum += no;
	     count++;
	     printf("Enter a number: ");
	     scanf("%f", &no);
	    }
       printf("Maximum = %g\n", max);
       printf("Minimum = %g\n", min);
       printf("Sum = %g\n", sum);
       printf("Average = %g\n", (float) sum / count);
      }
 getch();
}