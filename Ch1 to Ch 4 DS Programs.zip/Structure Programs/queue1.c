//structure implementation of queue
#include <stdio.h>
#include <conio.h>

#define MAX 5

typedef int qelement;

typedef struct
{qelement q[MAX];
 int front, rear;
}quetype;

void initialise(quetype *qptr)
{qptr->front = qptr-> rear = -1;}

int insertq(quetype *qptr, qelement no)
{if(qptr->rear == MAX -1 ) return 0;
 qptr->q[++qptr->rear] = no;
 return 1;
}

int delq(quetype *qptr, qelement *noptr)
{if(qptr->front == qptr->rear) return 0;
 *noptr = qptr->q[++qptr->front];
 return 1;
}

 
void printq(quetype que)
{int i;
 if(que.front == que.rear)
   printf("Queue Empty");
 else {for(i = que.front+1; i <= que.rear; i++)
	  printf("%d  ", que.q[i]);
       printf("\n");
      }
}

int main()
{
quetype que;
qelement no;
int choice;
initialise(&que);
do
{
clrscr();
printf("\nEnter 1 to add\nEnter 2 to delete\nEnter 3 to quit\nEnter your choice:");
scanf("%d", &choice);
switch(choice)
{case 1: printf("enter no to be added: ");
	 scanf("%d", &no);
	 if(!insertq(&que, no))
	   printf("Queue FULL");
	 printq(que); break;
 case 2: if(delq(&que, &no))
	   printf("No deleted = %d\n", no);
	 printq(que);
	 break;
}
getch();
}while(choice != 3);
return 0;
}
