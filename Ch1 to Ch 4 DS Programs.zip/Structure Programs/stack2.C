#include <conio.h>
#include <stdio.h>
#define MAX 10

typedef int stackelement;

typedef struct
{stackelement st[MAX];
 int top;
}stacktype;

void initialise(stacktype *sptr)
{sptr->top = -1;}

int push(stacktype *sptr, stackelement ch)
{if(sptr->top==MAX-1)return 0;
 sptr->st[++sptr->top] = ch;
 return 1;
}

int pop(stacktype *sptr, stackelement *noptr)
{if(sptr->top==-1)return 0;
 *noptr = sptr->st[sptr->top--];
 return 1;
}

void printstack(stacktype s)
{if(s.top == -1)
   printf("Stack Empty\n");
 else {int i;
       printf("The current stack is:\n");
       for(i = s.top; i >= 0; i--)
	  printf("%d\n", s.st[i]);
       }
}

void main()
{stacktype st;
 stackelement no;
 int choice;
 initialise(&st);
 do
 { clrscr();
   printf("Enter 1 to Push\n");
   printf("Enter 2 to Pop\n");
   printf("Enter 3 to print\n");
   printf("Enter 4 to quit\n");
   printf("Enter your choice: ");
   scanf("%d", &choice);
   switch(choice)
   {case 1: printf("Enter no: ");
	    scanf("%d", &no);
	    if(push(&st, no))
	      printf("Element pushed");
	    else printf("Stack Full\n");
	    break;
    case 2: if(pop(&st, &no))
	      printf("No popped = %d\n", no);
	    else printf("Stack empty\n");
	    break;
    case 3: printstack(st); break;
   }
   getch();
}while(choice != 4);
}
