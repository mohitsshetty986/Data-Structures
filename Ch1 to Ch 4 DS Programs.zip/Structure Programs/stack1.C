#define MAX 10

typedef int stackelement;

int push (stackelement no, int *topptr, stackelement s[])
{
if (*topptr == MAX-1) return 0;
s[++*topptr] = no;
return 1;
}

int pop (stackelement *no, int *topptr, stackelement s[])
{if (*topptr == -1) return 0;
*no = s[(*topptr)--];
return 1;
}

void printstack(stackelement s[], int top)
{int i;
if(top == -1)printf("Stack is Empty\n");
else for(i = top; i >= 0; i--)printf("%d\n", s[i]);
}


void main()
{
stackelement s[MAX], no;
int top = -1, i, choice ;
do
{
printf("Push(1) or Pop(2) or Quit(3):\t");
scanf("%d", &choice);
switch (choice)
{ case 1 : printf ("Enter the No to be pushed:\t");
	   scanf("%d", &no);
	   if (push(no, &top, s)==0) printf ("Can not push\n");
	   printf ("Current stack is:\n");
	   printstack(s, top);
	   break;
  case 2 : if (pop(&no, &top, s)==0)printf("Can not pop\n");
	   else printf("the no popped is %d\n", no);
	   printf ("Current stack is:\n");
	   printstack(s, top);
	   break;
}
} while (choice != 3);
}
