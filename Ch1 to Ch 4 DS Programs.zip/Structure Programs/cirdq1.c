//structure implementation of double ended circular queue option I

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#define MAX 10

typedef int qelement;
typedef struct
{ qelement q[MAX];
int first, last, count;} qtype;

void initialise(qtype *qptr)
{qptr->first = qptr->last = qptr->count = 0;}

int addleft(qtype *qptr, qelement no)
{
if (qptr->count == MAX) return 0;
qptr->q[qptr->first] = no;
qptr->first = (MAX + (qptr->first - 1)) % MAX;
qptr->count++;
return 1;
}

int addright(qtype *qptr, qelement no)
{
if (qptr->count == MAX) return 0;
qptr->last = (qptr->last+1) % MAX;
qptr->q[qptr->last] = no;
qptr->count++;
return 1;
}

int delleft(qtype *qptr, qelement *noptr)
{
if (qptr->count == 0) return 0;
qptr->first = (qptr->first +1) % MAX;
*noptr = qptr->q[qptr->first];
qptr->count--;
return 1;
}

int delright(qtype *qptr, qelement *noptr)
{if (qptr->count == 0) return 0;
*noptr = qptr->q[qptr->last];
qptr->last = (MAX + (qptr->last - 1)) % MAX;
qptr->count--;
return 1;
}
void printq(qtype que)
{
int i;
if(que.count == 0) printf ("Queue is Empty\n");
else { printf("The current Queue is :\n");
       if(que.last <= que.first)
	 {for(i = que.first+1; i < MAX; i++)
	      printf("%d  ", que.q[i]);
	  for(i = 0; i <= que.last; i++)
	      printf("%d  ", que.q[i]);
	 }
       else for(i = que.first + 1; i <= que.last; i++)
		printf("%d  ", que.q[i]);
     }
getch();
}

void main()
{
qtype que;
qelement no;
int i, choice;
initialise(&que);
do
{
clrscr();
printf("AddRight(1) or AddLeft(2)\nDeleteRight(3) or deleteLeft(4)\nQuit(5): ");
scanf("%d", &choice);
switch (choice)
{ case 1 : printf ("Enter the No to be added: ");
	   scanf("%d", &no);
	   if (addright(&que, no)==0) printf ("Can not add\n");
	   printq(que);
	   break;
  case 2 : printf ("Enter the No to be added: ");
	   scanf("%d", &no);
	   if (addleft(&que, no)==0) printf ("Can not add\n");
	   printq(que);
	   break;
  case 3 : if (delright(&que, &no)==0)printf("Can not delete\n");
	   else printf("the no deleted is %d\n", no);
	   printq(que);
	   break;
  case 4 : if (delleft(&que, &no)==0)printf("Can not delete\n");
	   else printf("the no deleted is %d\n", no);
	   printq(que);
	   break;
}
}while (choice != 5);
}
