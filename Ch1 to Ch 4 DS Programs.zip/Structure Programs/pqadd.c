//structure implementation of priority queue with normal addition

#include <stdio.h>
#include <conio.h>

#define MAX 5

typedef int qelement;
typedef struct
{qelement q[MAX];
 int rear;
}quetype;


void initialise(quetype *qptr)
{qptr->rear = -1;}

int addq(quetype *qptr, qelement no)
{if(qptr->rear == MAX-1) return 0;
 qptr->q[++qptr->rear] = no;
 return 1;
}

int delq(quetype *qptr, qelement *noptr)
{int pos = 0, i;
 if(qptr->rear == -1) return 0;
 for(i = pos+1; i <= qptr->rear; i++)
    if(qptr->q[i] > qptr->q[pos])
      pos = i;
 *noptr = qptr->q[pos];
 qptr->q[pos] = qptr->q[qptr->rear--];
 return 1;
}

void printq(quetype que)
{int i;
 if(que.rear == -1)
   printf("Empty Queue\n");
 else{printf("The current queue is:\n");
      for(i = 0; i <= que.rear; i++)
	 printf("%d ", que.q[i]);
      printf("\n");
     }
 getch();
}

int main()
{
quetype que;
qelement no;
int choice;
initialise(&que);
do
{
clrscr();
printf("Enter 1 to add\n");
printf("Enter 2 to delete\n");
printf("Enter 3 to quit\n");
printf("Enter your choice: ");
scanf("%d", & choice);
switch(choice)
{case 1: printf("Enter no: ");
	 scanf("%d", &no);
	 if(!addq(&que, no))
	   printf("Queue Full\n");
	 printq(que); break;
 case 2: if(delq(&que, &no))
	   printf("No deleted = %d\n", no);
	 printq(que); break;
}
}while(choice != 3);
return 0;
}
