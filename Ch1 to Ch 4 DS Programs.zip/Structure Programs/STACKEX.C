#include <stdio.h>
#include <conio.h>
#include "STACK.H"

void main()
{stacktype st1, st2;
 stackelement no;
 int n, i;
 initialise(&st1);
 initialise(&st2);
 clrscr();
 printf("How many elements you want to push? ");
 scanf("%d", &n);
 for(i = 1; i <= n; i++)
     {printf("Enter the elements: ");
      scanf("%d", &no);
      push(&st1, no);
     }
 printstack(st1);
 printf("Enter n <= %d: ", n);
 scanf("%d", &n);
 for(i = 1; i < n; i++)
    {pop(&st1, &no);
     push(&st2, no);
    }
 pop(&st1, &no);
 printf("The element required is %d\n", no);
 for(i = 1; i < n; i++)
    {pop(&st2, &no);
     push(&st1, no);
    }
 printstack(st1);
 getch();
}
