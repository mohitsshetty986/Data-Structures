//structure implementation of double ended queue

#include <stdio.h>
#include <conio.h>
#define MAX 5

typedef int qelement;
typedef struct
{qelement q[MAX];
 int front, rear;
}dqtype;

void initialise(dqtype *qptr)
{qptr->front = qptr-> rear = MAX/2;
}

int addright(dqtype *qptr, qelement no)
{if(qptr->rear== MAX-1) return 0;
 qptr->rear = qptr->rear+1;
 qptr->q[qptr->rear] = no;
 return 1;
}

int addleft(dqtype *qptr, qelement no)
{if(qptr->front== -1)return 0;
 qptr->q[qptr->front] = no;
 qptr->front--;
 return 1;
}

int delright(dqtype *qptr, qelement *noptr)
{if(qptr->front== qptr->rear)return 0;
 *noptr = qptr->q[qptr->rear];
 qptr->rear = qptr->rear-1;
 return 1;
}

int delleft(dqtype *qptr, qelement *noptr)
{if(qptr->front== qptr->rear)return 0;
 qptr->front = qptr->front+1;
 *noptr = qptr->q[qptr->front];
 return 1;
}

void printq(dqtype dq)
{if(dq.front== dq.rear)
   printf("Empty DQ\n");
 else {int i;
       printf("The Current DQ is:\n");
       for(i = dq.front+1; i <= dq.rear; i++)
	   printf("%d  ", dq.q[i]);
       printf("\n");
      }
}

int main()
{
dqtype dq;
int choice;
qelement no;
initialise(&dq);
do{
clrscr();
printf("Enter 1 to insert from right\n");
printf("Enter 2 to insert from left\n");
printf("Enter 3 to delete from right\n");
printf("Enter 4 to delete from left\n");
printf("Enter 5 to quit\n");
printf("Enter your choice: ");
scanf("%d", &choice);
switch(choice)
{case 1: printf("Enter the no to insert: ");
	 scanf("%d", &no);
	 if(!addright(&dq, no))
	    printf("DQ Full\n");
	 printq(dq); break;
 case 2: printf("Enter the no to insert: ");
	 scanf("%d", &no);
	 if(!addleft(&dq, no))
	    printf("DQ Full\n");
	 printq(dq); break;
 case 3: if(delright(&dq, &no))
	   printf("No deleted = %d\n", no);
	 printq(dq); break;
 case 4: if(delleft(&dq, &no))
	   printf("No deleted = %d\n", no);
	 printq(dq); break;
}
getch();
}while(choice != 5);
return 0;
}
