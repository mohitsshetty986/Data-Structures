#include <stdio.h>
#include <conio.h>
#define MAX 5
typedef int qelement;
typedef struct
{qelement q[MAX];
 int front, rear, lastoper;
}qtype;

void initialise(qtype *qptr)
{
 qptr->front = qptr-> rear = qptr->lastoper = 0;
}
int addq(qtype *qptr, qelement no)
{if(qptr->front == qptr->rear && qptr->lastoper == 1)return 0;
 if(qptr->rear == MAX-1)
   qptr->rear = 0;
 else qptr->rear++;
 qptr->q[qptr->rear] = no;
 qptr->lastoper = 1;
 return 1;
}
int delq(qtype *qptr, qelement *noptr)
{if(qptr->front == qptr->rear && qptr->lastoper == 0) return 0;
 if(qptr->front == MAX-1)
   qptr->front = 0;
 else qptr->front++;
 *noptr = qptr->q[qptr->front];
 qptr->lastoper = 0;
 return 1;
}
void printq(qtype que)
{if(que.front == que.rear && que.lastoper == 0)
   printf("Queue is empty\n");
 else {int i;
       if(que.rear > que.front)
	 {for(i = que.front + 1; i <= que.rear; i++)
	     printf("%d  ", que.q[i]);
	 }
       else {for(i = que.front+1; i <= MAX-1; i++)
		printf("%d  ", que.q[i]);
	     for(i = 0; i <= que.rear; i++)
		printf("%d  ", que.q[i]);
	    }
       printf("\n");
      }
}

void main()
{int choice;
 qtype que;
 qelement no;
 initialise(&que);
 do
 { clrscr();
   printf("Enter 1 to add\nEnter 2 to delete\nEnter 3 to print\nEnter 4 to quit\n");
   printf("Enter your choice: ");
   scanf("%d", &choice);
   switch(choice)
   {case 1: printf("Enter the no to be added: ");
	    scanf("%d", &no);
	    if(!addq(&que, no))
	      printf("Queue is FULL\n");
	    else printf("Added successfully\n");
	    break;
    case 2: if(!delq(&que, &no))
	      printf("Queue is empty\n");
	    else printf("No deleted = %d\n", no);
	    break;
    case 3: printq(que);
	    break;
   }
 getch();
 }while(choice != 4);
}



