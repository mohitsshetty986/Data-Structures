#include <stdio.h>
#include <conio.h>

void selection (int x[], int n)
{
 int i, j, pos, min;
 for(i = 0; i < n-1; i++)
    {min = x[i];
     pos = i;
     for (j = i+1; j < n; j++)
	 if(x[j] < min)
	   { min = x[j];
	     pos = j;
	   }
     x[pos] = x[i];
     x[i] = min;
    }
 return;
}

void main()
{
int i;
int a[] = {40, 70, 20, 90, 100, 80, 10, 60, 30, 50};
clrscr();
selection (a, 10);
for(i = 0; i < 10; i++)
    printf("%d ", a[i]);
printf("\n");
getch();
}