//Queue using LIFO Linked List
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

typedef int qelement;

typedef struct node
{ qelement data;
  struct node *next;
} node;

typedef struct
{ node *first, *last;}qtype;

void initialise(qtype *qptr)
{qptr->first = NULL;}
int addq(qtype *qptr, qelement no)
{node *p;
p = (node*) malloc (sizeof(node));
if(p==NULL) return 0;
p->data = no;
p->next = NULL;
if(qptr->first == NULL)
   qptr->first = p;
else qptr->last->next = p;
qptr->last = p;
return 1;
}

int delq (qtype *qptr, qelement *noptr)
{node *p = qptr->first;
if (p== NULL)return 0;
*noptr = p->data;
qptr->first = p->next;
free (p);
return 1;
}


void radix (int x[], int n, int digs)
{qtype q[10];
int i, j, k, no;
for(k = 1; k <= digs; k++)
   {for(i = 0; i < 10; i++)
       initialise(&q[i]);
    for (i = 0; i < n; i++)
	{ int dig;
	  dig = x[i]/ (int)(pow(10,k-1)) % 10;
	  addq(&q[dig], x[i]);
	}
    for (i = 0, j = 0; i < 10; i++)
	{ while (delq(&q[i], &no))
		x[j++] = no;
	}
   }
 return;
}
void main()
{int i, a[10]= {510, 920, 720, 180, 503, 301, 103, 708, 40, 360};
 clrscr();
 radix(a, 10, 3);
 for(i = 0; i < 10; i++)
    printf("%d  ", a[i]);
 printf("\n");
 getch();
}