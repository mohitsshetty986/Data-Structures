#include <stdio.h>
#include <conio.h>

void swap(int *a, int *b)
{ int temp = *a;
      *a = *b;
      *b = temp;
}

void heapup(int x[], int root, int bottom)
{
int parent, temp;
if(bottom > root)
  { parent = (bottom -1) / 2;
    if (x[parent] < x[bottom])
       {swap(&x[parent], &x[bottom]);
	heapup(x, root, parent);
       }
  }
}

void heapdown(int x[], int root, int bottom)
{int lchild = 2*root+1, rchild = 2*root+2, maxchild, temp;
  if (lchild <= bottom)
     {if(lchild == bottom)
	  maxchild = lchild;
      else if(x[lchild] > x[rchild])
	    maxchild = lchild;
	 else maxchild = rchild;
      if(x[root] < x[maxchild])
	{swap(&x[root], &x[maxchild]);
	 heapdown(x, maxchild, bottom);
	}
     }
}

void heapsort(int x[], int n)
{int i, temp;
for(i = 0; i < n-1; i++)
   heapup(x, 0, i+1);
for(i = n-1; i > 0; i--)
   {swap(&x[0], &x[i]);
    heapdown(x, 0, i-1);
   }
}

void main()
{
int i;
int a[] = {40, 70, 20, 90, 100, 80, 10, 60, 30, 50};
clrscr();
heapsort(a, 10);
for(i = 0; i < 10; i++)
    printf("%d ", a[i]);
printf("\n");
getch();
}