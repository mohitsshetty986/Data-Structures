#include <stdio.h>
#include <conio.h>

void mergesort(int x[], int n)
{int temp[10], i, j, k, lb1, lb2, ub1, ub2, size = 1;
while (size < n)
{lb1 = 0; k = 0;
while (lb1+size < n)
	{lb2= lb1+size;
	ub1 = lb2 - 1;
	ub2 = (ub1+size<n) ? ub1 + size :  n -1 ;
	i = lb1; j = lb2;
	while(i <= ub1 && j <= ub2)
	if(x[i] < x[j])
	   temp[k++] = x[i++];
	else temp[k++] = x[j++];
	while(i <= ub1)
	     temp[k++] = x[i++];
	while(j <= ub2)
	     temp[k++] = x[j++];
	lb1 = ub2 + 1;
	}
	for (i = 0;  i <= ub2; i++)
	x[i] = temp[i];
	size = 2 * size;
	}
}
void main()
{
int i;
int a[] = {40, 70, 20, 90, 100, 80, 10, 60, 30, 50};
clrscr();
mergesort(a, 10);
for(i = 0; i < 10; i++)
    printf("%d ", a[i]);
printf("\n");
getch();
}