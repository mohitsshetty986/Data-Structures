#include <stdio.h>
#include <conio.h>

void class_bubble (int x[], int n)
{int i, j, temp;
 for(i = 1; i < n; i++)
    for(j = 0; j < n-i; j++)
       if(x[j+1]<x[j])
	  {temp = x[j+1];
	   x[j+1] = x[j];
	   x[j] = temp;
	  }
 return;
}
void main()
{int i;
int a[] = {40, 70, 20, 90, 100, 80, 10, 60, 30, 50};
clrscr();
class_bubble(a, 10);
for(i = 0; i < 10; i++)
    printf("%d ", a[i]);
printf("\n");
getch();
}