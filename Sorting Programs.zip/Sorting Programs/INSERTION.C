#include <stdio.h>
#include <conio.h>

void insertion (int x[], int n)
{ int i, j, no;
  for (i = 0; i < n - 1; i++)
      { no = x[i+1];
	for( j = i; j >= 0; j--)
	   if( no < x[j])
	     x[j+1] = x[j];
	   else break;
	x[j+1] = no;
      }
  return;
}

void main()
{
int i;
int a[] = {40, 70, 20, 90, 100, 80, 10, 60, 30, 50};
clrscr();
insertion(a, 10);
for(i = 0; i < 10; i++)
    printf("%d ", a[i]);
printf("\n");
getch();
}