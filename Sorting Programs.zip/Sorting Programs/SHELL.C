#include <stdio.h>
#include <conio.h>

void shell (int x[], int n)
{int i, j, k, no, inc;
 for (inc = n/2; inc >=1; inc/=2)
     for (k = 0; k < inc ; k++)
	 {/* This is insertion sort */
	  for (i = k; i < n-inc; i+=inc)
	      { no = x[i+inc];
		for (j = i; j >= k; j-=inc)
		    if(no > x[j])
		       break;
		    else x[j+inc] = x[j];
		x[j+inc] = no;
	      }
	  /* insertion sort ends */
	  }
 return;
}
void main()
{
int i;
int a[] = {40, 70, 20, 90, 100, 80, 10, 60, 30, 50};
clrscr();
shell(a, 10);
for(i = 0; i < 10; i++)
    printf("%d ", a[i]);
printf("\n");
getch();
}