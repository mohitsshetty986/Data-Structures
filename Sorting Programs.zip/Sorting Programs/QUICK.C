#include <stdio.h>
#include <conio.h>
int partition (int x[], int lb, int ub)
{int pos = lb, i, temp;
 for (i = lb+1; i <= ub; i++)
    if (x[i] < x[lb])
       {pos++;
	temp = x[pos];
	x[pos] = x[i];
	x[i] = temp;
       }
 temp = x[pos];
 x[pos] = x[lb];
 x[lb] = temp;
 return pos;
}

void quicksort(int x[], int lb, int ub)
{int partition(int x[], int, int);
 int p;
 if(lb < ub)
   {p = partition(x, lb, ub);
    quicksort(x, lb, p-1);
    quicksort(x, p+1, ub);
   }
}

void main()
{
int i;
int a[] = {40, 70, 20, 90, 100, 80, 10, 60, 30, 50};
clrscr();
quicksort(a, 0, 9);
for(i = 0; i < 10; i++)
    printf("%d ", a[i]);
printf("\n");
getch();
}