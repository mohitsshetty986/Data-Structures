#include <stdio.h>
#include <conio.h>

void mergesort(int x[], int lb, int ub)
{ void merge(int [], int, int, int);
  int mid;
  if(lb < ub)
    {mid = (lb + ub) / 2;
     mergesort(x, lb, mid);
     mergesort(x, mid+1, ub);
     merge(x, lb, mid, ub);
    }
}
void merge(int x[], int lb1, int ub1, int ub2)
{
int temp[10], i = lb1, j = ub1 + 1, k = 0;
while(i <= ub1 && j <= ub2)
     if(x[i] < x[j])
       temp[k++] = x[i++];
     else temp[k++] = x[j++];
while(i <= ub1)
     temp[k++] = x[i++];
while(j <= ub2)
     temp[k++] = x[j++];
for (i = lb1, j = 0; i <= ub2; i++, j++)
	x[i] = temp[j];
}

void main()
{
int i;
int a[] = {40, 70, 20, 90, 100, 80, 10, 60, 30, 50};
clrscr();
mergesort(a, 0, 9);
for(i = 0; i < 10; i++)
    printf("%d ", a[i]);
printf("\n");
getch();
}